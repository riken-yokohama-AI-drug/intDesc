#!/bin/bash

set -eu

CMD="../interaction_descriptor.py"
VDW="data/vdw_radius.yaml"
PARAM="data/param.yaml"
PRIORITY="data/priority.yaml"

# 入力データの解凍
unzip data.zip

# 出力ディレクトリ作成
dir_name="result"
if [ ! -e ${dir_name} ]; then
    mkdir ${dir_name}
fi

# Ligand
ligand_list=("L_IT009" "L_IT010" "L_IT011" "L_IT012" "L_IT013" "L_IT014" "L_IT015" "L_IT016" "L_IT017" "L_IT018" "L_IT019" "L_IT020" "L_IT021" "L_IT022" "L_IT023" "L_IT024" "L_IT026" "L_IT027" "L_IT029" "L_IT030" "L_IT031" "L_IT032" "L_IT033" "L_IT036" "L_IT037" "L_IT038" "L_IT041" "L_IT042")
for id in ${ligand_list[@]}
do
    mol2="data/${id}/*.mol2"
    python ${CMD} ligand ${mol2} data/${id}/mol_select.yaml ${VDW} ${PARAM} ${PRIORITY} ${dir_name}/${id} &
    PID1=$!
    python ${CMD} ligand ${mol2} data/${id}/mol_select.yaml ${VDW} ${PARAM} ${PRIORITY} ${dir_name}/${id}_dup --dup &
    PID2=$!
    python ${CMD} ligand ${mol2} data/${id}/mol_select.yaml ${VDW} ${PARAM} ${PRIORITY} ${dir_name}/${id}_dup_on14 --dup --on_14 &
    PID3=$!
    python ${CMD} ligand ${mol2} data/${id}/mol_select.yaml ${VDW} ${PARAM} ${PRIORITY} ${dir_name}/${id}_on14 --on_14 &
    PID4=$!
    wait $PID1 $PID2 $PID3 $PID4
done

# 出力ファイルのチェック
cd ${dir_name}
md5sum -c ../data/check.md5
