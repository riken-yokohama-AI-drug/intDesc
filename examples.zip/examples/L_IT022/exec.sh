python ../../interaction_descriptor.py ligand \
				IT022_3vhdA_HSP90_moe_addH_minH_gasteiger_mod.mol2 \
				mol_select.yaml \
				../setup_files/vdw_radius.yaml \
				../setup_files/param.yaml \
				../setup_files/priority.yaml \
				L_IT022 

