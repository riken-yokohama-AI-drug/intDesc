python ../../interaction_descriptor.py ligand \
				IT029_5g4mA_p53_moe_addH_minH_gasteiger_mod.mol2 \
				mol_select.yaml \
				../setup_files/vdw_radius.yaml \
				../setup_files/param.yaml \
				../setup_files/priority.yaml \
				L_IT029 

