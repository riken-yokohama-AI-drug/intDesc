python ../../interaction_descriptor.py ligand \
				IT010_5tmn_thrmolysin_moe_new.mol2 \
				mol_select.yaml \
				../setup_files/vdw_radius.yaml \
				../setup_files/param.yaml \
				../setup_files/priority.yaml \
				L_IT010 

